import sklearn as sk
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import xgboost as xgb
from sklearn.preprocessing import StandardScaler
from scipy import stats
from sklearn.metrics import mean_squared_error
from math import sqrt

def calcMAE(observed: list, predicted: list):
  AEsum = 0
  for l in range(len(predicted)):
    AEsum += abs(predicted[l][0] - observed[l])
  return  AEsum / len(predicted)

allData = pd.read_csv('../data/combined_set.csv') 


#Extract the training and test sets here for each state of relevance.

#Define a list of states to extract data for.
states = ["ca", "fl", "ma", "ga", "tx"]
stateDict = {}

for s in states:
    #Filter out only the relevant state rows.
    stateDF = allData.loc[(allData["state"] == s)]
    #print(stateDF.iloc[:,5:])

    #Standard scale the 354 rows per state for both input and output variables. We have to scale because of the different data inputs.
    stateScaler = StandardScaler()
    stateScaler.fit(stateDF.iloc[:,2:])
    colNames = list(stateDF.columns)
    scaledState = stateScaler.transform(stateDF.iloc[:,2:]) #Columns 5: represent the input variables. 3 and 4 are cases and deaths, respectively.

    #Convert back to dataframe prior to saving.
    scaledState = pd.DataFrame(scaledState, columns=colNames[2:])

    #Add scaled state-specific set to the dictionary
    stateDict[s] = scaledState

model_list = ["XGB"]
feature_list = list(allData.columns)[4:]

MAEDict = {}
RMSEDict = {}
for s in states:
    MAElist = []
    RMSElist = []
    print("Evaluating " + s + " Data")
    for model in model_list:
        data = stateDict[s]
        train = data.iloc[:, 2:].fillna(method='bfill').fillna(method='ffill') 
        deaths = data["deaths"].tolist() #List of test data to train the model with.


        # get PCC values
        trainX = train.iloc[:650  , :]
        trainY = np.array(deaths[0:650 ])

        pcc_list = []
        for idx, symp in enumerate(feature_list):
            pcc_list.append(stats.pearsonr(trainY,trainX[symp].to_numpy())[0])
        df = pd.DataFrame({"Symptom":feature_list, "Correlation":pcc_list})
        df = df.sort_values(by=['Correlation'], ascending= False)
        name = "../data/" + model + "ordered_PCC.csv"
        df.to_csv(name)
        organized_feature_list = df["Symptom"].to_list()
        #Find the number of times the model will need to be retrained.

        for i in range(25, len(organized_feature_list), 25):
            curr_feat_list = organized_feature_list[:i]
            data = stateDict[s]
            train = data.loc[:,curr_feat_list].fillna(method='bfill').fillna(method='ffill')
            deaths = data["deaths"].tolist()

            rollIter = len(train.index) - 650
            mortPreds = []
            if model == "XGB":
                model = xgb.XGBRegressor(objective ='reg:squarederror')
            if model == "RF":
                model = sk.ensemble.RandomForestRegressor()
            if model == "LR":
                model = sk.linear_model.LinearRegression()
            
            for x in range(0,rollIter,1): #Do daily retrains up until the last day.

                #Begin predictions at day 301 of the state's data. The initial 300 days make up the first training set. Train and predict with all np arrays.
                trainX = train.iloc[:650 + x, :].to_numpy()
                trainY = np.array(deaths[0:650 + x])

                model.fit(trainX, trainY) #Since the input variables have to predict the next time step's deaths, offset test data by 1.
                nextInputs = np.reshape(train.iloc[650+x,:].to_numpy(), [1,-1])
                prediction = model.predict(nextInputs)

                #Save prediction, and then add the GROUND TRUTH value to the training set and rerun.
                mortPreds.append(prediction)

            #Calculate the summary statistics of this method: Mean Absolute Error and Root Mean-Squared Error.
            mortTrue = deaths[650:]
            MAE = calcMAE(mortTrue, mortPreds)
            RMSE = sqrt(mean_squared_error(mortTrue, mortPreds))
            
            MAElist.append(MAE)
            RMSElist.append(RMSE)



        MAEDict[s] = MAElist
        RMSEDict[s] = RMSElist
            
g = list(range(25,len(organized_feature_list),25))
g = [str(x) for x in g]

for s in stateDict:
  if s == "all":
    break
  fig, ax = plt.subplots()
  ax.plot(MAEDict[s], label = "MAE")
  ax.set_xlabel("Number of Features")
  ax.set_ylabel("MAE")
  ax.set_xticks(np.arange(len(g)))
  ax.set_xticklabels(g)
  title_str = s.upper() + " Ablation with MAE "
  ax.set_title(title_str)
  plt.savefig("../plots/" + s + "_ABLA_MAE_deaths.png")

for s in stateDict:
  if s == "all":
    break
  fig, ax = plt.subplots()
  ax.plot(RMSElist[s], label = "MAE")
  ax.set_xlabel("Number of Features")
  ax.set_ylabel("RSME")
  ax.set_xticks(np.arange(len(g)))
  ax.set_xticklabels(g)
  title_str = s.upper() + " Ablation with RSME "
  ax.set_title(title_str)
  plt.savefig("../plots/" + s + "_ABLA_RSME_deaths.png")


print("The resulting RSME are ", RMSEDict)
print("The resulting MAE are ", MAEDict)