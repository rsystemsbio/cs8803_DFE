import sklearn as sk
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import shap
import xgboost as xgb

from sklearn.preprocessing import StandardScaler

from sklearn.metrics import mean_squared_error
from math import sqrt

def calcMAE(observed: list, predicted: list):
  AEsum = 0
  for l in range(len(predicted)):
    AEsum += abs(predicted[l][0] - observed[l])
  return  AEsum / len(predicted)

allData = pd.read_csv('../data/combined_set.csv') 


#Extract the training and test sets here for each state of relevance.

#Define a list of states to extract data for.
states = ["ca", "fl", "ma", "ga", "tx"]
stateDict = {}

for s in states:
    #Filter out only the relevant state rows.
    stateDF = allData.loc[(allData["state"] == s)]
    #print(stateDF.iloc[:,5:])

    #Standard scale the 354 rows per state for both input and output variables. We have to scale because of the different data inputs.
    stateScaler = StandardScaler()
    stateScaler.fit(stateDF.iloc[:,2:])
    colNames = list(stateDF.columns)
    scaledState = stateScaler.transform(stateDF.iloc[:,2:]) #Columns 5: represent the input variables. 3 and 4 are cases and deaths, respectively.

    #Convert back to dataframe prior to saving.
    scaledState = pd.DataFrame(scaledState, columns=colNames[2:])

    #Add scaled state-specific set to the dictionary
    stateDict[s] = scaledState

#states.append("all")
feature_list = list(allData.columns)[4:]
out_feats = ["deaths", "cases"]
model_list = ["XGB", "RF", "LR"]

results_dict = {}
for s in states:
    print("Evaluating " + s + " Data")
    for model in model_list:
        
        results_dict[s][model] = {"MAE": [], "RSME": []}
        for feat in out_feats:
            print("Looking at " + model + " with " + feat)
            #Grab state data and split into train and test columns.
            data = stateDict[s]
            train = data.iloc[:, 2:].fillna(method='bfill').fillna(method='ffill') 
            deaths = data[feat].tolist() #List of test data to train the model with.

            #Find the number of times the model will need to be retrained.
            rollIter = len(train.index) - 650
            mortPreds = []
            if model == "XGB":
                model = xgb.XGBRegressor(objective ='reg:squarederror')
            if model == "RF":
                model = sk.ensemble.RandomForestRegressor()
            if model == "LR":
                model = sk.linear_model.LinearRegression()
            for x in range(0,rollIter,1): #Do daily retrains up until the last day.

                #Begin predictions at day 301 of the state's data. The initial 300 days make up the first training set. Train and predict with all np arrays.
                trainX = train.iloc[:650 + x, :].to_numpy()
                trainY = np.array(deaths[1:651 + x])

                model.fit(trainX, trainY) #Since the input variables have to predict the next time step's deaths, offset test data by 1.
                nextInputs = np.reshape(train.iloc[650+x,:].to_numpy(), [1,-1])
                prediction = model.predict(nextInputs)

                #Save prediction, and then add the GROUND TRUTH value to the training set and rerun.
                mortPreds.append(prediction)


            #Calculate the summary statistics of this method: Mean Absolute Error and Root Mean-Squared Error.
            mortTrue = deaths[650:]
            MAE = calcMAE(mortTrue, mortPreds)
            RMSE = sqrt(mean_squared_error(mortTrue, mortPreds))


            #Store the data from this state in a dict so they can be compared later.
            results_dict[s][model]["MAE"].append(MAE)
            results_dict[s][model]["RMSE"].append(RMSE) 

            #Use SHAP on the fully trained model. Produce a Beeswarm plot.
            explainer = shap.Explainer(model, train)
            shap_values = explainer(train)
            shap_values.feature_names = feature_list
            plt.figure()
            shap.plots.beeswarm(shap_values, max_display = 10, show=False )
            out_str = "../plots/" + s + "_SHAP_" + model +"_" + feat + ".png"
            plt.tight_layout()
            plt.savefig(out_str)

  
print("The resulting scores for each model and feature prediction is", results_dict)