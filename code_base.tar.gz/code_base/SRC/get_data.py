import pandas as pd
from datetime import date
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import colorcet as cc
import umap
from sklearn.preprocessing import StandardScaler
import os.path as pth
import covidcast


# check if data has been downloaded
#Google Search Terms Aggregation
#enter each link into browser to download
# https://storage.cloud.google.com/gcs-public-data---symptom-search/2020/country/daily/2020_US_daily_symptoms_dataset.csv
# https://storage.cloud.google.com/gcs-public-data---symptom-search/2021/country/daily/2021_US_daily_symptoms_dataset.csv
# https://storage.cloud.google.com/gcs-public-data---symptom-search/2022/country/daily/2022_US_daily_symptoms_dataset.csv
google_data_paths = ["../data/2020_country_daily_2020_US_daily_symptoms_dataset.csv",
 "../data/2021_country_daily_2021_US_daily_symptoms_dataset.csv",
 "../data/2022_country_daily_2022_US_daily_symptoms_dataset.csv"]


if not (pth.exists(google_data_paths[0])) or not (pth.exists(google_data_paths[1]) )or not (pth.exists(google_data_paths[2])):
    raise Exception("The data from Google Search Terms has not been downloaded and placed in the data folder. Please check README.")


google_20 = pd.read_csv(google_data_paths[0])
google_21 = pd.read_csv(google_data_paths[1])
google_22 = pd.read_csv(google_data_paths[2])

google_df = pd.concat([google_20, google_21, google_22], axis=0)

google_df.to_csv('../data/google_search_terms.csv')


#API Call
geo_type = 'state'
start = date(2020, 5, 1)
end = date(2022, 11, 19)
data_sources = {'fb-survey': ['smoothed_wcli'], 'jhu-csse': ['deaths_7dav_incidence_prop', 'confirmed_7dav_incidence_prop'], 'safegraph':['restaurants_visit_num', 'bars_visit_num']}
end_dates = {}
google_search_file = '../data/google_search_terms.csv'
filenames = [google_search_file]
for data_source in data_sources:
    for signal in data_sources[data_source]:
        data = covidcast.signal(data_source, signal, start, end, geo_type)
        end_dates[signal] = data['time_value'].max()
        name = "../data/" + data_source[:2]+'_'+signal+'.csv'
        filenames.append(name)
        data.to_csv(name)


#what length to trim the dataset to
max_date = min(end_dates.values())
#states to ignore
set_list = ['as', 'gu', 'mp', 'pr', 'ri', 'vi']

new_df = pd.DataFrame()
for name in filenames:
  df = pd.read_csv(name)
  #adapt naming for google search set
  if name == '../data/google_search_terms.csv':
    dt = 'date'
    df['geo_value'] = df['sub_region_1_code'].str[-2:]
    df = df[df['geo_value'].notna()]
  else:
    dt = 'time_value'
  df['geo_value'] = df['geo_value'].str.lower()

  #remove unuseful states
  df = df[~df['geo_value'].isin(set_list)]
  df[dt] = pd.to_datetime(df[dt])
  
  #ensuring time range is within the smallest dataset listed
  df = df[df[dt]<= max_date]
  df = df[df[dt]>= np.datetime64(start)]

  #initiate dataframe
  if name == '../data/google_search_terms.csv':
    spike_cols = [col for col in df.columns if 'symptom' in col]
    new_df['geo_value'] = df['geo_value']
    new_df['time_value'] = df['date']
    new_df[spike_cols] = df[spike_cols]
  #add API value columns
  else:
    temp = pd.merge(new_df, df,on='time_value', how='left')
    new_df[name[:-4]] = temp['value']

new_df.iloc[3:,:].rolling(window=7).mean()
#Save final aggregated dataset
new_df.to_csv('../data/combined_set.csv')


#Convert Datetime to Month
new_df['Month'] = pd.to_datetime(new_df['time_value'], format='%Y-%m-%d').dt.month_name().str.slice(stop=3)

#Fit UMAP
reducer = umap.UMAP()
cols_data = new_df[new_df.columns.to_list()[2:-1]].values
scaled_cols_data = StandardScaler().fit_transform(cols_data)
scaled_cols_data = np.nan_to_num(scaled_cols_data)
embedding = reducer.fit_transform(scaled_cols_data)



#Plot UMAP Embeddings
fig, ax = plt.subplots(figsize=(10,8))
scatter = plt.scatter(
    embedding[:, 0],
    embedding[:, 1], 
    c=[sns.color_palette(cc.glasbey, n_colors=12)[x] for x in new_df.Month.map({'Jan':3, 'Feb':3, 'Mar':5,'Apr':5,'May':5,'Jun':7,'Jul':7,'Aug':7,'Sep':9,'Oct':9,'Nov':9,'Dec':3})],
    )
blue = sns.color_palette(cc.glasbey, n_colors=12)[3]
pink = sns.color_palette(cc.glasbey, n_colors=12)[5]
orange = sns.color_palette(cc.glasbey, n_colors=12)[7]
tur= sns.color_palette(cc.glasbey, n_colors=12)[9]
colors_ = [blue, pink, orange, tur]
seasons = ['Winter', 'Spring', 'Summer', 'Fall']
#plt.legend((seasons, colors_), title="Seasons")
#plt.legend(loc="upper left")
plt.title("UMAP of Aggregated Covid Timeseries Data By Season", size = 20)
plt.savefig("../plots/UMAP_COVID.png")